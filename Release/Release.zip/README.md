# Ravager
- Adds the Ravager, an original new character
- Fully functional base kit
- Has item displays
- Full Risk of Options support for all configuration options
- May not work in multiplayer, recommend playing him only as host for now

[![](https://raw.githubusercontent.com/ArcPh1r3/RedGuyMod/main/Release/FuckShit/screen1.png)]()

[![](https://raw.githubusercontent.com/ArcPh1r3/RedGuyMod/main/Release/FuckShit/screen2.png)]()

[![](https://raw.githubusercontent.com/ArcPh1r3/RedGuyMod/main/Release/FuckShit/screen3.png)]()

[![](https://raw.githubusercontent.com/ArcPh1r3/RedGuyMod/main/RedGuyUnityProject/Assets/Ravager/Icons/texRavagerIcon.png)]()

To share feedback, report bugs, or offer suggestions feel free to create an issue on the GitHub repo

___

# Unlock

Currently comes unlocked by default

___

# Skills

i'll do this at some point

___

## Donations
If you enjoy my work and would like to support me, you can donate to my Ko-fi: https://ko-fi.com/robdev

## Credits
rob - Everything

Swuff - Feedback, character icon outline

Moffein, TheTimeSweeper - Loads of valuable feedback


## Future Plans
- Unlockable skins
- Alternate skills
- Ancient Scepter support
- Better item displays
- General polish

___

## Changelog

`1.0.0`
- Initial release